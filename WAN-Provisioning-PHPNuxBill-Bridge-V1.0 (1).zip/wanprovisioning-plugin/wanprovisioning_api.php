<?php
/**
 * WAN Provisioning bridge for PHPNuxBill.
 * Install in system/plugin/wanprovisioning_api.php
 * Route: /?_route=plugin/wanprovisioning_api/plans
 *        /?_route=plugin/wanprovisioning_api/register
 */

function wanprovisioning_api()
{
    global $routes, $config, $admin, $zero;

    $root = dirname(__DIR__, 2);
    $cfgFile = $root . '/wanprovisioning.config.php';
    $bridge = is_file($cfgFile) ? require $cfgFile : [];
    if (!is_array($bridge)) $bridge = [];

    $json = function (int $status, array $payload): void {
        http_response_code($status);
        header('Content-Type: application/json; charset=utf-8');
        header('Cache-Control: no-store');
        echo json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        exit;
    };

    if (empty($bridge['enabled'])) $json(503, ['ok'=>false, 'error'=>'WAN Provisioning bridge is disabled']);
    $expected = (string)($bridge['api_secret'] ?? '');
    $provided = (string)($_SERVER['HTTP_X_WANPROV_KEY'] ?? '');
    if ($expected === '' || $provided === '' || !hash_equals($expected, $provided)) {
        $json(401, ['ok'=>false, 'error'=>'Unauthorized']);
    }

    $action = (string)($routes[2] ?? '');
    if ($action === 'plans') {
        if (($_SERVER['REQUEST_METHOD'] ?? 'GET') !== 'GET') $json(405, ['ok'=>false,'error'=>'Method not allowed']);
        $plans = ORM::for_table('tbl_plans')
            ->where('type', 'PPPOE')->where('enabled', 1)->order_by_asc('name_plan')->find_many();
        $out = [];
        foreach ($plans as $p) {
            $out[] = [
                'id' => (int)$p['id'],
                'name' => (string)$p['name_plan'],
                'price' => (string)$p['price'],
                'validity' => (string)$p['validity'],
                'validity_unit' => (string)$p['validity_unit'],
                'type' => (string)$p['type'],
            ];
        }
        $json(200, ['ok'=>true, 'plans'=>$out]);
    }

    if ($action !== 'register') $json(404, ['ok'=>false,'error'=>'Unknown action']);
    if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') $json(405, ['ok'=>false,'error'=>'Method not allowed']);

    $raw = file_get_contents('php://input');
    $in = json_decode($raw, true);
    if (!is_array($in)) $json(400, ['ok'=>false,'error'=>'Invalid JSON body']);

    $fullname = trim((string)($in['fullname'] ?? ''));
    $username = preg_replace('/\s+/', '_', $fullname);
    $username = alphanumeric($username, ":+_.@-");
    $phone = trim((string)($in['phonenumber'] ?? ''));
    $address = trim((string)($in['address'] ?? ''));
    $email = trim((string)($in['email'] ?? ''));
    $pppoePassword = trim((string)($in['pppoe_password'] ?? ''));
    $billingPassword = trim((string)($in['billing_password'] ?? ''));
    $planId = (int)($in['plan_id'] ?? 0);
    $using = trim((string)($in['using'] ?? ($bridge['default_payment_method'] ?? 'Cash')));

    if (mb_strlen($fullname, 'UTF-8') < 2 || mb_strlen($fullname, 'UTF-8') > 36) $json(422,['ok'=>false,'error'=>'Nama lengkap harus 2–36 karakter']);
    if (strlen($username) < 3 || strlen($username) > 54) $json(422,['ok'=>false,'error'=>'Username hasil nama tidak valid']);
    if ($phone === '') $json(422,['ok'=>false,'error'=>'Nomor HP wajib diisi']);
    if ($pppoePassword === '') $json(422,['ok'=>false,'error'=>'Password PPPoE wajib diisi']);
    if (strlen($billingPassword) < 3 || strlen($billingPassword) > 35) $json(422,['ok'=>false,'error'=>'Password billing harus 3–35 karakter']);
    if ($planId < 1) $json(422,['ok'=>false,'error'=>'Paket internet belum dipilih']);

    $plan = ORM::for_table('tbl_plans')->where('id', $planId)->where('type', 'PPPOE')->where('enabled', 1)->find_one();
    if (!$plan) $json(422,['ok'=>false,'error'=>'Paket PPPoE tidak ditemukan atau tidak aktif']);

    $exists = ORM::for_table('tbl_customers')->where('username', $username)->find_one();
    if ($exists) $json(409,['ok'=>false,'error'=>'Username pelanggan sudah terdaftar','username'=>$username]);
    $pppExists = ORM::for_table('tbl_customers')->where('pppoe_username', $username)->find_one();
    if ($pppExists) $json(409,['ok'=>false,'error'=>'Username PPPoE sudah digunakan','username'=>$username]);

    $adminId = (int)($bridge['admin_id'] ?? 0);
    if ($adminId < 1) $json(503,['ok'=>false,'error'=>'admin_id belum dikonfigurasi pada wanprovisioning.config.php']);
    $adminRow = ORM::for_table('tbl_users')->where('id', $adminId)->find_one();
    if (!$adminRow || !in_array((string)$adminRow['user_type'], ['SuperAdmin','Admin'], true)) {
        $json(503,['ok'=>false,'error'=>'Admin billing untuk proses registrasi tidak valid']);
    }

    // Set the same trusted admin context used by the built-in Quick Add workflow.
    $admin = $adminRow->as_array();
    $zero = 0;
    $customer = ORM::for_table('tbl_customers')->create();
    $customer->username = $username;
    $customer->password = $billingPassword;
    $customer->pppoe_username = $username;
    $customer->pppoe_password = $pppoePassword;
    $customer->pppoe_ip = '';
    $customer->email = $email;
    $customer->account_type = 'Personal';
    $customer->fullname = $fullname;
    $customer->address = $address;
    $customer->created_by = $adminId;
    $customer->phonenumber = Lang::phoneFormat($phone);
    $customer->service_type = 'PPPOE';
    $customer->city = trim((string)($in['city'] ?? ''));
    $customer->save();
    $customerId = (int)$customer->id();

    $server = (string)$plan['routers'];
    if ((string)$plan['is_radius'] === '1') $server = 'Radius';
    try {
        $recharged = Package::rechargeUser($customerId, $server, (int)$plan['id'], $using, (string)$admin['fullname']);
    } catch (Throwable $e) {
        _log('WAN Provisioning recharge failed for customer '.$customerId.': '.$e->getMessage());
        $json(500,['ok'=>false,'stage'=>'customer_created_recharge_failed','customer_id'=>$customerId,'username'=>$username,'error'=>'Akun pelanggan dibuat, tetapi aktivasi paket gagal. Periksa billing sebelum mencoba ulang.']);
    }
    if (!$recharged) {
        $json(500,['ok'=>false,'stage'=>'customer_created_recharge_failed','customer_id'=>$customerId,'username'=>$username,'error'=>'Akun pelanggan dibuat, tetapi aktivasi paket tidak berhasil. Periksa billing sebelum mencoba ulang.']);
    }

    $json(201, [
        'ok'=>true,
        'message'=>'Pelanggan berhasil dibuat dan paket berhasil diproses',
        'customer'=>[
            'id'=>$customerId,
            'fullname'=>$fullname,
            'username'=>$username,
            'pppoe_username'=>$username,
            'phonenumber'=>(string)$customer->phonenumber,
            'plan_id'=>(int)$plan['id'],
            'plan_name'=>(string)$plan['name_plan'],
        ]
    ]);
}
