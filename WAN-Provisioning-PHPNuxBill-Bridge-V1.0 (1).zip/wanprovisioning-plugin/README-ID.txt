WAN PROVISIONING BRIDGE - PHPNuxBill
====================================

PENTING
- Ini plugin tambahan. Tidak mengubah quickadd.php atau file inti PHPNuxBill.
- Uji dahulu di staging/backup. Endpoint register membuat pelanggan dan memproses aktivasi paket.
- Jangan unggah file konfigurasi contoh dengan secret default ke server produksi.

INSTALASI
1. Backup folder PHPNuxBill dan database.
2. Upload wanprovisioning_api.php ke: system/plugin/wanprovisioning_api.php
3. Salin wanprovisioning.config.example.php ke root PHPNuxBill dengan nama:
   wanprovisioning.config.php
4. Edit wanprovisioning.config.php:
   - enabled = true
   - api_secret = secret acak kuat minimal 64 karakter hex
   - admin_id = ID akun Admin/SuperAdmin yang akan tercatat sebagai pembuat pelanggan
   - default_payment_method = salah satu nilai yang diizinkan pada billing (misalnya Cash)
5. Pastikan root PHPNuxBill tidak bisa mengunduh file konfigurasi. Tambahkan aturan deny untuk
   wanprovisioning.config.php pada .htaccess bila server Apache.
6. Pastikan HTTPS aktif.

ENDPOINT
Daftar paket PPPoE:
GET https://DOMAIN-BILLING/?_route=plugin/wanprovisioning_api/plans
Header: X-WANPROV-KEY: SECRET

Registrasi:
POST https://DOMAIN-BILLING/?_route=plugin/wanprovisioning_api/register
Header: X-WANPROV-KEY: SECRET
Content-Type: application/json

Contoh JSON:
{
  "fullname":"Budi Santoso",
  "phonenumber":"08123456789",
  "address":"Alamat pemasangan",
  "email":"",
  "pppoe_password":"password-pppoe",
  "billing_password":"password-akun-billing",
  "plan_id":12,
  "using":"Cash"
}

Username billing dan PPPoE otomatis dibuat dari fullname dengan spasi menjadi underscore.

CATATAN KEAMANAN & OPERASIONAL
- Jangan bagikan api_secret kepada pihak lain.
- Endpoint hanya menerima request dengan secret yang benar.
- Daftar paket hanya menampilkan paket PPPoE aktif.
- Username billing/PPPoE dicek duplikat sebelum pembuatan.
- Jika aktivasi paket gagal setelah akun dibuat, API mengembalikan stage
  customer_created_recharge_failed. Jangan langsung kirim ulang; cek akun di billing dahulu.
- Lakukan uji dengan satu pelanggan dummy dan paket uji sebelum produksi.
