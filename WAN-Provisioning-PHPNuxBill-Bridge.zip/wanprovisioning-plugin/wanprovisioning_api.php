<?php
/**
 * WAN Provisioning bridge for PHPNuxBill.
 * Install in system/plugin/wanprovisioning_api.php
 * Routes:
 *   GET  /?_route=plugin/wanprovisioning_api/plans
 *   GET  /?_route=plugin/wanprovisioning_api/customer&username=PPPOE_USERNAME
 *   POST /?_route=plugin/wanprovisioning_api/register
 */

function wanprovisioning_api()
{
    global $routes, $config, $admin, $zero;

    $root = dirname(__DIR__, 2);
    $cfgFile = $root . '/wanprovisioning.config.php';
    $bridge = is_file($cfgFile) ? require $cfgFile : [];
    if (!is_array($bridge)) $bridge = [];

    $json = function (int $status, array $payload): void {
        http_response_code($status);
        header('Content-Type: application/json; charset=utf-8');
        header('Cache-Control: no-store');
        echo json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        exit;
    };

    if (empty($bridge['enabled'])) $json(503, ['ok'=>false, 'error'=>'WAN Provisioning bridge is disabled']);
    $expected = (string)($bridge['api_secret'] ?? '');
    $provided = (string)($_SERVER['HTTP_X_WANPROV_KEY'] ?? '');
    if ($expected === '' || $provided === '' || !hash_equals($expected, $provided)) {
        $json(401, ['ok'=>false, 'error'=>'Unauthorized']);
    }

    $action = (string)($routes[2] ?? '');
    if ($action === 'plans') {
        if (($_SERVER['REQUEST_METHOD'] ?? 'GET') !== 'GET') $json(405, ['ok'=>false,'error'=>'Method not allowed']);
        $plans = ORM::for_table('tbl_plans')
            ->where('type', 'PPPOE')->where('enabled', 1)->order_by_asc('name_plan')->find_many();
        $out = [];
        foreach ($plans as $p) {
            $out[] = [
                'id' => (int)$p['id'],
                'name' => (string)$p['name_plan'],
                'price' => (string)$p['price'],
                'validity' => (string)$p['validity'],
                'validity_unit' => (string)$p['validity_unit'],
                'type' => (string)$p['type'],
            ];
        }
        $json(200, ['ok'=>true, 'plans'=>$out]);
    }

    // Paginated customer list for the Telegram "Detail Pelanggan" menu.
    // Fixed page size of 25; only non-sensitive display fields are returned.
    if ($action === 'customers') {
        if (($_SERVER['REQUEST_METHOD'] ?? 'GET') !== 'GET') $json(405, ['ok'=>false,'error'=>'Method not allowed']);
        $page = max(1, (int)($_GET['page'] ?? 1));
        $limit = 25;
        $offset = ($page - 1) * $limit;
        if ($offset > 1000000) $json(422, ['ok'=>false,'error'=>'Nomor halaman terlalu besar']);

        // Idiorm find_many() returns an IdiormResultSet, not a native PHP array.
        // Materialize it before using array operations such as array_slice().
        $resultSet = ORM::for_table('tbl_customers')
            ->order_by_desc('id')
            ->limit($limit + 1)
            ->offset($offset)
            ->find_many();

        $rows = [];
        foreach ($resultSet as $row) {
            $rows[] = $row;
        }

        $hasMore = count($rows) > $limit;
        if ($hasMore) {
            $rows = array_slice($rows, 0, $limit);
        }

        $items = [];
        foreach ($rows as $row) {
            $c = $row->as_array();
            $id = (int)($c['id'] ?? 0);
            $r = [];
            if ($id > 0) {
                try {
                    $recharge = ORM::for_table('tbl_user_recharges')
                        ->where('customer_id', $id)
                        ->order_by_desc('id')
                        ->find_one();
                    if ($recharge) $r = $recharge->as_array();
                } catch (Throwable $e) {
                    $r = [];
                }
            }

            $planName = (string)($r['namebp'] ?? '');
            $planId = (int)($r['plan_id'] ?? 0);
            if ($planId > 0) {
                try {
                    $plan = ORM::for_table('tbl_plans')->where('id', $planId)->find_one();
                    if ($plan) $planName = (string)($plan['name_plan'] ?? $planName);
                } catch (Throwable $e) {}
            }

            $rawStatus = trim((string)($c['status'] ?? $c['enabled'] ?? $r['status'] ?? ''));
            $statusKey = strtolower($rawStatus);
            if (in_array($statusKey, ['1','active','aktif','enabled','yes'], true)) $status = 'Active';
            elseif (in_array($statusKey, ['0','inactive','nonaktif','disabled','no','off'], true)) $status = 'Inactive';
            else $status = $rawStatus !== '' ? $rawStatus : 'Tidak diketahui';

            $expiration = trim((string)($r['expiration'] ?? $r['expiry'] ?? $r['expire_date'] ?? ''));
            // Expired means the expiry DATE is earlier than today's date in the PHPNuxBill server timezone.
            // Keep blank/zero/invalid dates as unknown rather than incorrectly marking them expired.
            if ($expiration !== '' && !in_array($expiration, ['0000-00-00', '0000-00-00 00:00:00'], true)) {
                try {
                    $expiryDate = new DateTimeImmutable($expiration);
                    $today = new DateTimeImmutable('today');
                    if ($expiryDate->format('Y-m-d') < $today->format('Y-m-d')) {
                        $status = 'Expired';
                    }
                } catch (Throwable $e) {
                    // Leave the billing status unchanged if the date cannot be parsed.
                }
            }

            $items[] = [
                'fullname' => (string)($c['fullname'] ?? ''),
                'username' => (string)($c['pppoe_username'] ?? $c['username'] ?? ''),
                'status' => $status,
                'plan_name' => $planName,
                'expiration' => $expiration,
            ];
        }
        $json(200, ['ok'=>true, 'page'=>$page, 'per_page'=>$limit, 'has_more'=>$hasMore, 'customers'=>$items]);
    }

    // Minimal customer profile lookup for WAN Provisioning.
    // Sensitive fields (billing password, PPPoE password, balance, ODP) are never returned.
    if ($action === 'customer') {
        if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'GET') $json(405, ['ok'=>false,'error'=>'Method not allowed']);
        $lookup = trim((string)($_GET['username'] ?? ''));
        if ($lookup === '' || mb_strlen($lookup, 'UTF-8') > 80) {
            $json(422, ['ok'=>false,'error'=>'Username PPPoE wajib diisi (maksimal 80 karakter)']);
        }

        // Exact match only; no partial username search.
        $customer = ORM::for_table('tbl_customers')->where('pppoe_username', $lookup)->find_one();
        if (!$customer) $customer = ORM::for_table('tbl_customers')->where('username', $lookup)->find_one();
        if (!$customer) $json(404, ['ok'=>false,'error'=>'Pelanggan tidak ditemukan']);

        $c = $customer->as_array();
        $customerId = (int)($c['id'] ?? 0);
        $r = [];
        try {
            if ($customerId > 0) {
                $recharge = ORM::for_table('tbl_user_recharges')
                    ->where('customer_id', $customerId)->order_by_desc('id')->find_one();
                if ($recharge) $r = $recharge->as_array();
            }
        } catch (Throwable $e) {
            $r = [];
        }

        $planName = (string)($r['namebp'] ?? '');
        $planId = (int)($r['plan_id'] ?? 0);
        if ($planId > 0) {
            try {
                $plan = ORM::for_table('tbl_plans')->where('id', $planId)->find_one();
                if ($plan) $planName = (string)($plan['name_plan'] ?? $planName);
            } catch (Throwable $e) {
                // Retain the recharge snapshot name when plan lookup is unavailable.
            }
        }

        $rawStatus = trim((string)($c['status'] ?? $c['enabled'] ?? $r['status'] ?? ''));
        $statusKey = strtolower($rawStatus);
        if (in_array($statusKey, ['1','active','aktif','enabled','yes'], true)) $billingStatus = 'Active';
        elseif (in_array($statusKey, ['0','inactive','nonaktif','disabled','no','off'], true)) $billingStatus = 'Inactive';
        else $billingStatus = ($rawStatus !== '' ? $rawStatus : 'Tidak diketahui');

        $json(200, ['ok'=>true, 'customer'=>[
            'id'=>$customerId,
            'fullname'=>(string)($c['fullname'] ?? ''),
            'username'=>(string)($c['username'] ?? ''),
            'pppoe_username'=>(string)($c['pppoe_username'] ?? $c['username'] ?? ''),
            'billing_status'=>$billingStatus,
            'service_type'=>(string)($c['service_type'] ?? ''),
            'plan_name'=>$planName,
            'expiration'=>(string)($r['expiration'] ?? $r['expiry'] ?? $r['expire_date'] ?? ''),
            'account_type'=>(string)($c['account_type'] ?? ''),
            'phonenumber'=>(string)($c['phonenumber'] ?? ''),
            'address'=>(string)($c['address'] ?? ''),
        ]]);
    }

    if ($action !== 'register') $json(404, ['ok'=>false,'error'=>'Unknown action']);
    if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') $json(405, ['ok'=>false,'error'=>'Method not allowed']);

    $raw = file_get_contents('php://input');
    $in = json_decode($raw, true);
    if (!is_array($in)) $json(400, ['ok'=>false,'error'=>'Invalid JSON body']);

    $fullname = trim((string)($in['fullname'] ?? ''));
    $username = preg_replace('/\s+/', '_', $fullname);
    $username = alphanumeric($username, ":+_.@-");
    $phone = trim((string)($in['phonenumber'] ?? ''));
    $address = trim((string)($in['address'] ?? ''));
    $email = trim((string)($in['email'] ?? ''));
    $pppoePassword = trim((string)($in['pppoe_password'] ?? ''));
    $billingPassword = trim((string)($in['billing_password'] ?? ''));
    $planId = (int)($in['plan_id'] ?? 0);
    $using = trim((string)($in['using'] ?? ($bridge['default_payment_method'] ?? 'Cash')));

    if (mb_strlen($fullname, 'UTF-8') < 2 || mb_strlen($fullname, 'UTF-8') > 36) $json(422,['ok'=>false,'error'=>'Nama lengkap harus 2–36 karakter']);
    if (strlen($username) < 3 || strlen($username) > 54) $json(422,['ok'=>false,'error'=>'Username hasil nama tidak valid']);
    if ($phone === '') $json(422,['ok'=>false,'error'=>'Nomor HP wajib diisi']);
    if ($pppoePassword === '') $json(422,['ok'=>false,'error'=>'Password PPPoE wajib diisi']);
    if (strlen($billingPassword) < 3 || strlen($billingPassword) > 35) $json(422,['ok'=>false,'error'=>'Password billing harus 3–35 karakter']);
    if ($planId < 1) $json(422,['ok'=>false,'error'=>'Paket internet belum dipilih']);

    $plan = ORM::for_table('tbl_plans')->where('id', $planId)->where('type', 'PPPOE')->where('enabled', 1)->find_one();
    if (!$plan) $json(422,['ok'=>false,'error'=>'Paket PPPoE tidak ditemukan atau tidak aktif']);

    $exists = ORM::for_table('tbl_customers')->where('username', $username)->find_one();
    if ($exists) $json(409,['ok'=>false,'error'=>'Username pelanggan sudah terdaftar','username'=>$username]);
    $pppExists = ORM::for_table('tbl_customers')->where('pppoe_username', $username)->find_one();
    if ($pppExists) $json(409,['ok'=>false,'error'=>'Username PPPoE sudah digunakan','username'=>$username]);

    $adminId = (int)($bridge['admin_id'] ?? 0);
    if ($adminId < 1) $json(503,['ok'=>false,'error'=>'admin_id belum dikonfigurasi pada wanprovisioning.config.php']);
    $adminRow = ORM::for_table('tbl_users')->where('id', $adminId)->find_one();
    if (!$adminRow || !in_array((string)$adminRow['user_type'], ['SuperAdmin','Admin'], true)) {
        $json(503,['ok'=>false,'error'=>'Admin billing untuk proses registrasi tidak valid']);
    }

    // Set the same trusted admin context used by the built-in Quick Add workflow.
    $admin = $adminRow->as_array();
    $zero = 0;
    $customer = ORM::for_table('tbl_customers')->create();
    $customer->username = $username;
    $customer->password = $billingPassword;
    $customer->pppoe_username = $username;
    $customer->pppoe_password = $pppoePassword;
    $customer->pppoe_ip = '';
    $customer->email = $email;
    $customer->account_type = 'Personal';
    $customer->fullname = $fullname;
    $customer->address = $address;
    $customer->created_by = $adminId;
    $customer->phonenumber = Lang::phoneFormat($phone);
    $customer->service_type = 'PPPOE';
    $customer->city = trim((string)($in['city'] ?? ''));
    $customer->save();
    $customerId = (int)$customer->id();

    $server = (string)$plan['routers'];
    if ((string)$plan['is_radius'] === '1') $server = 'Radius';
    try {
        $recharged = Package::rechargeUser($customerId, $server, (int)$plan['id'], $using, (string)$admin['fullname']);
    } catch (Throwable $e) {
        _log('WAN Provisioning recharge failed for customer '.$customerId.': '.$e->getMessage());
        $json(500,['ok'=>false,'stage'=>'customer_created_recharge_failed','customer_id'=>$customerId,'username'=>$username,'error'=>'Akun pelanggan dibuat, tetapi aktivasi paket gagal. Periksa billing sebelum mencoba ulang.']);
    }
    if (!$recharged) {
        $json(500,['ok'=>false,'stage'=>'customer_created_recharge_failed','customer_id'=>$customerId,'username'=>$username,'error'=>'Akun pelanggan dibuat, tetapi aktivasi paket tidak berhasil. Periksa billing sebelum mencoba ulang.']);
    }

    $json(201, [
        'ok'=>true,
        'message'=>'Pelanggan berhasil dibuat dan paket berhasil diproses',
        'customer'=>[
            'id'=>$customerId,
            'fullname'=>$fullname,
            'username'=>$username,
            'pppoe_username'=>$username,
            'phonenumber'=>(string)$customer->phonenumber,
            'plan_id'=>(int)$plan['id'],
            'plan_name'=>(string)$plan['name_plan'],
        ]
    ]);
}
