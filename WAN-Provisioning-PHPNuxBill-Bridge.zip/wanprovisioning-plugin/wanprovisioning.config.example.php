<?php
// Upload/copy this file to the PHPNuxBill installation root as:
// wanprovisioning.config.php
// Generate api_secret with: php -r "echo bin2hex(random_bytes(32)), PHP_EOL;"
return [
    'enabled' => true,
    'api_secret' => 'GANTI_DENGAN_SECRET_ACAK_MINIMAL_64_HEX',
    // ID akun Admin/SuperAdmin PHPNuxBill khusus untuk mencatat registrasi dari bot.
    'admin_id' => 1,
    'default_payment_method' => 'Cash',
];
